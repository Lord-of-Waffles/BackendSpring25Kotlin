package fi.haagahelia.homework2worton_backend25

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class Homework2wortonBackend25Application

fun main(args: Array<String>) {
	runApplication<Homework2wortonBackend25Application>(*args)
}
