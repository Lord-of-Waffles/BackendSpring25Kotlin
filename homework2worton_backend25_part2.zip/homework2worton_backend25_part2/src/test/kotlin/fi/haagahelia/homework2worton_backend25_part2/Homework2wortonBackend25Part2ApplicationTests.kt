package fi.haagahelia.homework2worton_backend25_part2

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class Homework2wortonBackend25Part2ApplicationTests {

	@Test
	fun contextLoads() {
	}

}
