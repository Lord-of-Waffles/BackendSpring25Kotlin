package fi.haagahelia.homework2worton_backend25_part2.domain

data class Friend(val firstName: String, val lastName: String)